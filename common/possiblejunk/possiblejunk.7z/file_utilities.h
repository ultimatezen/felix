#if !defined(FILE_UTILITIES_H__71A49E41_5FCD_4071_9C79_DD4106DC118F__INCLUDED_)
#define FILE_UTILITIES_H__71A49E41_5FCD_4071_9C79_DD4106DC118F__INCLUDED_

// shell api support
#include "shlwapi.h"
#pragma comment(lib, "shlwapi.lib")

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#endif
