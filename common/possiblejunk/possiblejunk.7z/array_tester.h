#pragma once

#ifdef _DEBUG

#include "Array.h"


void test_Array() ;


#endif // #ifdef _DEBUG
