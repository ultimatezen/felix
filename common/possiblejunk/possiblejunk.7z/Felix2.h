// Felix2.h: interface for the Felix2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_Felix2_H__4588AF65_7964_4976_9350_2B7656BB0CA2__INCLUDED_)
#define AFX_Felix2_H__4588AF65_7964_4976_9350_2B7656BB0CA2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FelixObj.h"

class CMemory 
{
	typedef CComPtr< IMemory > mem_ptr ;

public:
	
};

class CFelix2  
{
public:
	CFelix2(){}
	virtual ~CFelix2(){}

};

#endif // !defined(AFX_Felix2_H__4588AF65_7964_4976_9350_2B7656BB0CA2__INCLUDED_)
