// ComBSTREx.h: interface for the CComBSTREx class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMBSTREX_H__98C9AA4A_BC7A_4C00_8943_260966CFE7CF__INCLUDED_)
#define AFX_COMBSTREX_H__98C9AA4A_BC7A_4C00_8943_260966CFE7CF__INCLUDED_

#include "atlbase.h"
#include <string>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CComBSTREx : public CComBSTR  
{
public:
	CComBSTREx();
	virtual ~CComBSTREx();


};



#endif // !defined(AFX_COMBSTREX_H__98C9AA4A_BC7A_4C00_8943_260966CFE7CF__INCLUDED_)
